Memory Music 1.0.0 build 32 — native component corresponding source
=================================================================

This archive supplies the Chromaprint native component and its Flutter FFI
wrapper, the native source copies actually compiled by the Apple targets,
configuration headers, original notices, LGPL 2.1 text, wrapper modifications,
and a standalone Apple SDK rebuild recipe. See SOURCE_VERSION.json for the
exact pinned commits. Native source is unchanged relative to that pinned commit.

Chromaprint includes FFmpeg avresample code under LGPL 2.1 or later; its native
whole must not be treated as MIT-only. KISS FFT has its own BSD-style notice.
The Dart wrapper has its original MIT notice. Original copyright/license
notices and the complete LGPL text are retained in this archive and the app.

The rebuild recipe requires an existing official Xcode installation and Python 3.
It performs local compiler operations only; no signing, network, device install,
user-media access or changes to the installed app. Choose a NEW output directory:

  python3 rebuild.py --platform macos --arch arm64 --output /chosen/new/mac-build
  python3 rebuild.py --platform macos --arch x86_64 --output /chosen/new/intel-build
  python3 rebuild.py --platform ios --arch arm64 --output /chosen/new/ios-build

For a diagnostic, interface-compatible version-string change in a build copy:

  python3 rebuild.py --platform macos --marker --output /chosen/new/modified-build

The optional marker changes only chromaprint_get_version; the fingerprinting
algorithm is unchanged. It is not used in the shipped product sources.
The script verifies the 24 exported Chromaprint C functions. A built framework
is unsigned. Any local test installation needs your own lawful Apple signing
and provisioning arrangement appropriate to your platform. Do not disable
platform protections or replace files in your only installed app or backup.

The app loads the framework dynamically from Contents/Frameworks on macOS or
Frameworks on iOS, through chromaprint_flutter/lib/chromaprint.dart. The Apple
Standard EULA preserves permissions granted by the applicable open-source
licenses. Those licenses govern these components and permit the modifications
and debugging they describe. This source download is not a new application
EULA, legal opinion, signing credential, distribution approval or app binary.

Scope of current validation: standalone native rebuild and matching synthetic
fingerprints; modified-library loading in a separate verification host is
tracked independently. Full App Store library replacement/re-signing conditions
remain under review. Availability of this archive alone does not assert those
conditions have all been satisfied. No private app business source, original
audio, music library, personal database, receipt or credential is included.

Questions about the materials: kenapple9527@gmail.com

The upstream test.mp3 fixture is omitted. It is not compiled into the native
library; all 21 compiled native sources, headers and build configuration remain.
